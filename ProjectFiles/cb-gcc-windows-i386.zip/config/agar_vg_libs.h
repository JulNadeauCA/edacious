#ifndef AGAR_VG_LIBS
#define AGAR_VG_LIBS "ag_vg"
#endif
