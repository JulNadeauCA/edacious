#ifndef LIBDIR
#define LIBDIR "/usr/local/lib/agar-eda"
#endif
