#ifndef AGAR_VG_CFLAGS
#define AGAR_VG_CFLAGS ""
#endif
