#ifndef INCLDIR
#define INCLDIR "/usr/local/include/agar-eda"
#endif
