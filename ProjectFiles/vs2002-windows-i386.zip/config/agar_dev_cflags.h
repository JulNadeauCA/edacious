#ifndef AGAR_DEV_CFLAGS
#define AGAR_DEV_CFLAGS ""
#endif
