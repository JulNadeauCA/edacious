#ifndef BINDIR
#define BINDIR "/usr/local/bin"
#endif /* BINDIR */
