#ifndef VERSION
#define VERSION "04052008"
#endif
