--
-- Do not edit!
-- This file was generated from Makefile by BSDbuild 2.3.
--
-- To regenerate this file, get the latest BSDbuild release from
-- http://hypertriton.com/bsdbuild/, the latest Premake release
-- (v3 series) from http://premake.sourceforge.net/, and execute:
--
--     $ make proj
--
project.name = "agar-eda"
dopackage("Schematics")
package = newpackage()
package.name = "eda"
package.kind = "winexe"
package.guid = "2dc24ff4-7e71-4a98-84db-0abc0af29030"
dofile("configure.lua")
tinsert(package.links, { "ag_core", "SDL" })
tinsert(package.links, { "ag_core" })
tinsert(package.links, { "ag_gui", "SDL", "opengl32", "freetype" })
tinsert(package.links, { "ag_sc" })
tinsert(package.links, { "ag_dev" })
tinsert(package.links, { "ag_vg" })
if (hdefs["HAVE_PTHREADS"] ~= nil) then
	if (windows) then
		table.insert(package.links, { "pthreadVC2" })
	else
		table.insert(package.links, { "pthread" })
	end
end
if (hdefs["HAVE_SDL"] ~= nil) then
	tinsert(package.links, { "SDL", "SDLmain" })
end
if (hdefs["HAVE_SDL"] ~= nil) then
	tinsert(package.links, { "SDL", "SDLmain" })
end
if (hdefs["HAVE_OPENGL"] ~= nil) then
	if (windows) then
		tinsert(package.links, { "opengl32" })
	else
		tinsert(package.links, { "GL" })
	end
end
if (hdefs["HAVE_FREETYPE"] ~= nil) then
	table.insert(package.links, { "freetype" })
end
package.files = {
	"and.c",
	"circuit.c",
	"component.c",
	"dc.c",
	"digital.c",
	"ground.c",
	"insert_tool.c",
	"inverter.c",
	"led.c",
	"logic_probe.c",
	"main.c",
	"or.c",
	"resistor.c",
	"schem.c",
	"schem_block.c",
	"schem_circle_tool.c",
	"schem_line_tool.c",
	"schem_point_tool.c",
	"schem_port.c",
	"schem_port_tool.c",
	"schem_proximity_tool.c",
	"schem_select_tool.c",
	"schem_text_tool.c",
	"schem_wire.c",
	"schem_wire_tool.c",
	"scope.c",
	"select_tool.c",
	"semiresistor.c",
	"sim.c",
	"spdt.c",
	"spice.c",
	"spst.c",
	"vsine.c",
	"vsource.c",
	"vsquare.c",
	"wire.c",
}
