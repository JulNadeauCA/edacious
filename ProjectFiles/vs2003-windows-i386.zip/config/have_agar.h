#ifndef HAVE_AGAR
#define HAVE_AGAR "yes"
#endif
