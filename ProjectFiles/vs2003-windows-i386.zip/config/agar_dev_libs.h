#ifndef AGAR_DEV_LIBS
#define AGAR_DEV_LIBS "ag_dev"
#endif
