#ifndef MANDIR
#define MANDIR "/usr/local/share/man"
#endif /* MANDIR */
