#ifndef TTFDIR
#define TTFDIR "/usr/local/share/agar-eda/fonts"
#endif
